package Task1;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;


public class Test1 {


    public ExtentReports reports = new ExtentReports("C:\\Absa_assesment\\reports\\Assessment-Report.html");
    public ExtentTest test = reports.startTest("Dog Breeds", "TEST REPORT");


    public void ignoreCert() throws Exception {
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }};
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
    }

    @org.junit.Test
    public void getListofAllDogBreed() throws Exception {
        test.log(LogStatus.INFO, "Test Automation Test Started");
        test.assignCategory("DOG BREEDTEST");
        test.assignAuthor("XOLISA MOYENI");
        StringBuilder stringBuilder = new StringBuilder("https://dog.ceo/api/breeds/list/all");
        ignoreCert();
        URL obj = new URL(stringBuilder.toString());
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");


        System.out.println("\nSending request to URL : " + stringBuilder);
        System.out.println("Response Code : " + con.getResponseCode());
        System.out.println("Response Message : " + con.getResponseMessage());

        test.getDescription();
        test.getRunStatus();
        test.getStartedTime();
        test.getEndedTime();
        test = reports.startTest("1.Get list of all dog breeds ");


        if (con.getResponseCode() == 200) {
            test.log(LogStatus.PASS, " Get list of all dog breed  STATUS CODE : " + con.getResponseCode());
            test.log(LogStatus.PASS, "RESPONSE MESSAGE : " + con.getResponseMessage());
        } else
            test.log(LogStatus.FAIL, "Expected Status code : 200 but received : " + con.getResponseCode());

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String line;
        StringBuffer response = new StringBuffer();

        while ((line = in.readLine()) != null) {
            response.append(line);
        }

        System.out.println("---------GET LIST OF ALL DOG BREED----------");
        System.out.println(response.toString());

        /*Using code, verify “retriever” breed is within the list. (Diagram 2)*/
        test.log(LogStatus.INFO, response.toString());
        if (response.toString().contains("retriever")) {
            test.log(LogStatus.PASS, "retriever is within the list");
            System.out.println("retriever is within the list");
        } else test.log(LogStatus.FAIL, "retriever is not within the list");
        System.out.println("retriever is not within the list");

        getListofSubBreed();
        getRandomImage();
    }

    public void getListofSubBreed() throws Exception {
        StringBuilder stringBuilder = new StringBuilder("https://dog.ceo/api/breed/retriever/list");
        ignoreCert();
        URL obj = new URL(stringBuilder.toString());
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");

        test = reports.startTest("2. GET LIST OF SUB BREEDS");
        System.out.println("\nSending request to URL : " + stringBuilder);
        System.out.println("Response Code : " + con.getResponseCode());
        System.out.println("Response Message : " + con.getResponseMessage());

        if (con.getResponseCode() == 200) {
            test.log(LogStatus.PASS, " Get list of all list breeds  STATUS CODE : " + con.getResponseCode());
            test.log(LogStatus.PASS, "RESPONSE MESSAGE : " + con.getResponseMessage());
        } else
            test.log(LogStatus.FAIL, "Expected Status code : 200 but received : " + con.getResponseCode());

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String line;
        StringBuffer response = new StringBuffer();

        while ((line = in.readLine()) != null) {
            response.append(line);
        }
        test.log(LogStatus.INFO, response.toString());

        System.out.println("---------GET LIST OF SUB BREED----------");
        System.out.println(response.toString());


    }

    /*Perform an API request to produce a random image / link for the sub-breed “golden*/
    public void getRandomImage() throws Exception {
        StringBuilder stringBuilder = new StringBuilder("https://dog.ceo/api/breed/retriever/golden/images/random");
        ignoreCert();
        URL obj = new URL(stringBuilder.toString());
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        test = reports.startTest("3. GET RANDOM IMAGE/LINK");

        System.out.println("\nSending request to URL : " + stringBuilder);
        System.out.println("Response Code : " + con.getResponseCode());
        System.out.println("Response Message : " + con.getResponseMessage());

        if (con.getResponseCode() == 200) {
            test.log(LogStatus.PASS, " Get list random image/link  STATUS CODE : " + con.getResponseCode());
            test.log(LogStatus.PASS, "RESPONSE MESSAGE : " + con.getResponseMessage());
        } else
            test.log(LogStatus.FAIL, "Expected Status code : 200 but received : " + con.getResponseCode());

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String line;
        StringBuffer response = new StringBuffer();

        while ((line = in.readLine()) != null) {
            response.append(line);
        }
        test.log(LogStatus.INFO, response.toString());
        System.out.println("---------GET RANDOM IMAGE FOR SUB BREED GOLDEN----------");
        System.out.println(response.toString());


        reports.endTest(test);
        reports.flush();


    }
}
