package Task2;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import java.io.FileInputStream;
import java.io.IOException;

public class Test2 {
    public static final String excel_location = "C:\\Absa_assesment\\TestData\\DataSheet.xlsx";
    FileInputStream fis = new FileInputStream(excel_location);
    XSSFWorkbook workbook = new XSSFWorkbook(fis);
    WebDriver driver;

    public Test2() throws IOException {
    }

    @Before
    public void launchBrowser()throws Exception {
       // WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Absa_assesment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        driver = new ChromeDriver(op);
        driver.get("https://www.way2automation.com/angularjs-protractor/webtables/");
        Thread.sleep( 5500 );
       //  driver.manage().window().maximize();

    }
    @Test
    public void addUser() throws Exception{
        XSSFSheet sheet = workbook.getSheetAt(0);
        String firstname = sheet.getRow(1).getCell(0).getStringCellValue();
        String lastname = sheet.getRow(1).getCell(1).getStringCellValue();
        String username = sheet.getRow(1).getCell(2).getStringCellValue();
        String password = sheet.getRow(1).getCell(3).getStringCellValue();
       String email = sheet.getRow(1).getCell(4).getStringCellValue();
       String cellphone = String.valueOf(sheet.getRow(1).getCell(5).getNumericCellValue());
        driver.findElement(By.xpath("/html/body/table/thead/tr[2]/td/button")).click();

        Thread.sleep(2000);
        driver.findElement(By.name("FirstName")).sendKeys(firstname);
        driver.findElement(By.name("LastName")).sendKeys(lastname);
        driver.findElement(By.name("UserName")).sendKeys(username);
        driver.findElement(By.name("Password")).sendKeys(password);
        driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/table/tbody/tr[5]/td[2]/label[1]/input")).click();
        driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/table/tbody/tr[6]/td[2]/select")).click();
        Thread.sleep(2000);
        Select se = new Select(driver.findElement(By.xpath("/html/body/div[3]/div[2]/form/table/tbody/tr[6]/td[2]/select")));
        Thread.sleep(100);
        se.selectByValue("2");
        driver.findElement(By.name("Email")).sendKeys(email);
        driver.findElement(By.name("Mobilephone")).sendKeys(cellphone);
}

}
