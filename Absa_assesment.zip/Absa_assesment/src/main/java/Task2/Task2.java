package Task2;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Task2 {

    @Test
    public void launchBrowser()throws Exception {
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Absa_assesment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        driver = new ChromeDriver(op);
        driver.get("https://www.way2automation.com/angularjs-protractor/webtables/");
        Thread.sleep( 5500 );
       //  driver.manage().window().maximize();

    }


}
